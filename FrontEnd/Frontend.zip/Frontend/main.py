from flask import Flask, render_template, request, redirect, url_for
from sqlalchemy import text
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import random
app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:mp09lh3818@localhost/dailydairy'
db = SQLAlchemy(app)

class Cart(db.Model):
    Cart_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Cart_Value = db.Column(db.Integer, nullable=False)
    customers=db.relationship('Customer', backref='cartbr')

class Adds(db.Model):
    Customer_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Product_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Cart_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Quantity = db.Column(db.Integer, nullable=False)

class Customer(db.Model):
    Customer_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    First_Name = db.Column(db.String(50), nullable=False)
    Last_Name = db.Column(db.String(50), nullable=False)
    Apartment_Number = db.Column(db.Integer, nullable=False)
    Locality = db.Column(db.String(100), nullable=False)
    City = db.Column(db.String(50), nullable=False)
    State = db.Column(db.String(50), nullable=False)
    Pincode = db.Column(db.Integer, nullable=False)
    Password = db.Column(db.String(50), nullable=False)
    Email_ID = db.Column(db.String(50), nullable=False, unique=True)
    Cart_ID = db.Column(db.Integer, db.ForeignKey('cart.Cart_ID'))

class gives_product_feedback(db.Model):
    Customer_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Product_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Order_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Rating = db.Column(db.Integer, nullable=False)

@app.route("/")
def home():
    return render_template('index.html')

@app.route("/signup", methods=['GET', 'POST'])
def signup():
    if(request.method=='POST'):
        cart = Cart(Cart_Value=0)
        firstname = request.form.get('firstname')
        lastname = request.form.get('lastname')
        ap_num = request.form.get('ap_num')
        locality = request.form.get('locality')
        city = request.form.get('city')
        state = request.form.get('state')
        pincode = request.form.get('pincode')
        password = request.form.get('password')
        email = request.form.get('email')
        entry = Customer(First_Name=firstname, Last_Name=lastname, Apartment_Number=ap_num, Locality=locality, City=city, State=state, Pincode=pincode, Password=password, Email_ID=email, cartbr=cart)
        db.session.add(cart)
        db.session.add(entry)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route("/login", methods = ['GET', 'POST'])
def login():
    if(request.method=='POST'):
        email = request.form.get('email')
        password = request.form.get('password')
        result = db.session.execute(text('SELECT Customer.Customer_ID, Customer.Email_ID, Customer.Password FROM Customer'))
        for output in result:
            if(email==output[1] and password==output[2]):
                return redirect(url_for('account', id=output[0]))
        
    return render_template('login.html')

@app.route("/account/<int:id>", methods=["GET"])
def account(id):  
    acc = Customer.query.filter_by(Customer_ID=id).first()
    return render_template('account.html', cus=acc)

@app.route("/Payment/<int:cid>/<int:oid>/<int:amount>")
def Payment(cid, oid, amount):
    transaction_number = random.randint(1000000, 9999999)
    db.session.execute(text("START TRANSACTION;INSERT INTO `payment`(`Customer_ID`, `Order_ID`, `Amount`, `Transaction_Number`) VALUES ("+str(cid)+", "+str(oid)+", "+str(amount)+", "+str(transaction_number)+");UPDATE `customer` SET `Money In Wallet` = `Money In Wallet` - "+str(amount)+" WHERE `Customer_ID` = "+str(cid)+";UPDATE `admin` SET `Money` = `Money` + "+str(amount)+";"))
    db.session.commit()
    return redirect(url_for('Products', id=cid))

@app.route("/Products/<int:id>", methods=["GET", "POST"])
def Products(id):
    Pro = db.session.execute(text('SELECT * FROM Product'))
    if(request.method=='POST'):
        description = request.form.get('description')
        Pro = db.session.execute(text("SELECT * FROM Product WHERE Product.`Description` LIKE '%" + description +"%';"))
    Pro_Cart = db.session.execute(text('SELECT * FROM Adds where Adds.Customer_ID='+str(id)))
    Value = db.session.execute(text('SELECT Cart.Cart_Value From Cart where Cart.Cart_ID='+str(id)))
    for item in db.session.execute(text('SELECT `Money In Wallet` from customer where customer_id=' + str(id))):
        money = item[0]
    value=0
    for val in Value:
        value=val
    acc = Customer.query.filter_by(Customer_ID=id).first()
    L = []
    for items in Pro_Cart:
        L.append(items)
    return render_template('product.html', cus=acc, pro=Pro, id=id, Pro_Cart=L, value=value[0], money = money)

@app.route("/add_product/<int:pid>/<int:cid>", methods=["GET"])
def add_product(pid, cid):  
    if(request.method=='GET'):
        Pro_Cart = db.session.execute(text('SELECT * FROM Adds where Adds.Customer_ID='+str(cid)+' and Adds.Product_ID='+str(pid)))
        L = []
        for items in Pro_Cart:
            L.append(items)
        if(L==[]):
            add = Adds(Customer_ID = cid, Product_ID=pid, Quantity=1, Cart_ID = cid)
            db.session.add(add)
            db.session.commit()
        else:
            for i in Adds.query.filter_by(Customer_ID=cid, Product_ID=pid):
                i.Quantity = i.Quantity+1
            db.session.flush()
            db.session.commit()
        return redirect(url_for('Products', id=cid))
@app.route("/delete_product/<int:pid>/<int:cid>", methods=["GET"])
def delete_product(pid, cid):  
    if(request.method=='GET'):
        Pro_Cart = db.session.execute(text('SELECT * FROM Adds where Adds.Customer_ID='+str(cid)+' and Adds.Product_ID='+str(pid)))
        L = []
        for items in Pro_Cart:
            L.append(items)
        if(L!=[]):
            for i in Adds.query.filter_by(Customer_ID=cid, Product_ID=pid):
                if(i.Quantity>0):
                    i.Quantity = i.Quantity-1
                if(i.Quantity==0):
                    db.session.delete(i)
            db.session.flush()
            db.session.commit()
        return redirect(url_for('Products', id=cid))
@app.route("/remove_product/<int:pid>/<int:cid>", methods=["GET"])
def remove_product(pid, cid):  
    if(request.method=='GET'):
        Pro_Cart = db.session.execute(text('SELECT * FROM Adds where Adds.Customer_ID='+str(cid)+' and Adds.Product_ID='+str(pid)))
        L = []
        for items in Pro_Cart:
            L.append(items)
        if(L!=[]):
            for i in Adds.query.filter_by(Customer_ID=cid, Product_ID=pid):
                db.session.delete(i)
            db.session.commit()
        return redirect(url_for('Products', id=cid))

@app.route("/Orders/<int:id>", methods=["GET"])
def Orders(id):
    acc = Customer.query.filter_by(Customer_ID=id).first()
    orders = db.session.execute(text('SELECT * FROM `order` where `order`.Customer_ID='+str(id)))
    return render_template('orders.html', O=orders, id=id, cus=acc)

@app.route("/OrderDetails/<int:cid>/<int:oid>", methods=["GET"])
def OrderDetails(cid, oid):
    acc = Customer.query.filter_by(Customer_ID=cid).first() 
    given_feedback = db.session.execute(text('select gives_product_feedback.Product_ID from gives_product_feedback where gives_product_feedback.Order_ID='+str(oid)+' and gives_product_feedback.Customer_ID='+str(cid)))
    L = []
    for items in given_feedback:
        L.append(items[0])
    pro = db.session.execute(text('select * from order_placing inner join Product on Product.Product_ID=order_placing.Product_ID where order_placing.Order_ID='+str(oid)))
    return render_template('order_details.html', id=cid, oid=oid, cus=acc, pro=pro, given_feedback=L)

@app.route("/Rating/<int:cid>/<int:oid>/<int:pid>", methods=["POST"])
def Rating(cid, oid, pid): 
    if(request.method=='POST'):
        rating = int(request.form.get('rating'))
        db.session.execute(text('START TRANSACTION;SET @Customer_ID = '+str(cid)+';SET @Order_ID='+str(oid)+';SET @Product_ID = '+str(pid)+';SET @Rating = '+str(rating)+';INSERT INTO `gives_product_feedback` VALUES (@Customer_ID, @Order_ID, @Product_ID, @Rating);UPDATE `Product` SET Average_Rating = (SELECT AVG(gives_product_feedback.Rating) FROM gives_product_feedback WHERE gives_product_feedback.Product_ID = @Product_ID) WHERE `Product_ID` = @Product_ID;COMMIT;'))
        db.session.commit()
    return redirect(url_for('OrderDetails', cid=cid, oid=oid))

@app.route("/Place_order/<int:cid>", methods=["GET"])
def Place_Order(cid): 
    if(request.method=='GET'):
        o = db.session.execute(text('SELECT MAX(order_id) FROM `order`'))
        delivery_man_id = random.randint(1, 100)
        warehouse_id = random.randint(1, 100)
        v = db.session.execute(text('SELECT cart_value FROM Cart WHERE cart.cart_id=' + str(cid) + ';'))
        for item in o:
            order_id = item[0]+1
        for item in v:
            order_value = item[0]
        for item in db.session.execute(text('SELECT `Money in Wallet` from customer where customer_id = '+str(cid))):
            money = item[0]
        if(money>=order_value):
            db.session.execute(text("INSERT INTO `order` VALUES ("+str(order_id)+"," +"'Order Confirmed'"+", "+str(delivery_man_id)+", "+str(warehouse_id)+", "+str(cid)+", "+str(order_value)+");"))
            db.session.execute(text('INSERT INTO `order_placing`(`product_id`, `order_id`, `cart_id`, `quantity`) SELECT `product_id`,'+ str(order_id)+', '+str(cid)+', quantity FROM Adds WHERE `Customer_ID` = '+str(cid)+';'))
            db.session.execute(text('DELETE FROM adds WHERE customer_id='+str(cid)+';'))
            db.session.commit()
            return redirect(url_for('Payment', cid=cid, oid=order_id, amount=order_value))
        return redirect(url_for('Products', id=cid))
@app.route("/wallet/<int:cid>", methods=['GET', 'POST'])
def wallet(cid):
    if(request.method=='POST'):
        money = int(request.form.get('money'))
        word = request.form.get('password')
        for item in db.session.execute(text('SELECT Password from customer where customer_id='+str(cid))):
            password = item[0]
        if(password==word):
            db.session.execute(text('UPDATE customer SET `Money In Wallet`=`Money In Wallet`+' + str(money) + ' WHERE customer_id='+str(cid)))
            db.session.commit()
    for item in db.session.execute(text('SELECT `money in wallet` from customer where customer_ID=' + str(cid))):
        m = item[0]
    return render_template('wallet.html', id=cid, m=m)

@app.route("/index_admin", methods=['GET', 'POST'])
def index_admin():
    return render_template('admin_index.html')

@app.route("/login_admin", methods=['GET', 'POST'])
def login_admin():
    if(request.method=='POST'):
        admin_id = request.form.get('admin_id')
        password = request.form.get('password')
        result = db.session.execute(text('SELECT Admin_ID, Password FROM Admin'))
        for output in result:
            if(int(admin_id)==int(output[0]) and password==output[1]):
                return redirect(url_for('account_admin', aid=output[0]))
    return render_template('admin_login.html')

@app.route("/account_admin/<int:aid>", methods=['GET', 'POST'])
def account_admin(aid):
    return render_template('admin_account.html', aid=aid)

@app.route("/products_admin/<int:aid>", methods = ['GET', 'POST'])
def products_admin(aid):
    products = db.session.execute(text('SELECT * FROM Product'))
    return render_template('admin_products.html', pro=products, aid=aid)

@app.route("/update_price/<int:aid>/<int:pid>", methods=['GET', 'POST'])
def update_price(aid, pid):
    if(request.method=='POST'):
        new_price = int(request.form.get('new_price'))
        db.session.execute(text('START TRANSACTION;SET @product_id = '+str(pid)+';SET @old_value = (SELECT Product_Value FROM product WHERE product_id=@product_id);SET @new_value = '+str(new_price)+';UPDATE cart, adds SET cart.cart_value = cart_value + adds.Quantity*(@new_value - @old_value) WHERE cart.Cart_ID = adds.Cart_ID AND adds.Product_ID=@product_id;UPDATE product SET product_value = @new_value WHERE product_id=@product_id;COMMIT;'))
    return redirect(url_for('products_admin', aid=aid))

@app.route("/wallet_admin/<int:aid>", methods=['GET', 'POST'])
def wallet_admin(aid):
    if(request.method=='POST'):
        money = int(request.form.get('money'))
        word = request.form.get('password')
        for item in db.session.execute(text('SELECT Password from Admin where admin_id='+str(aid))):
            password = item[0]
        if(password==word):
            db.session.execute(text('UPDATE Admin SET `Money`=`Money`+' + str(money) + ' WHERE admin_id='+str(aid)))
            db.session.commit()
    for item in db.session.execute(text('SELECT `Money` from Admin where Admin_ID=' + str(aid))):
        m = item[0]
    return render_template('admin_wallet.html', aid=aid, m=m)

@app.route("/farmers_admin/<int:aid>", methods=['GET', 'POST'])
def farmers_admin(aid):
    farmers = []
    for item in db.session.execute(text('SELECT * from farmer')):
        for i in db.session.execute(text('SELECT SUM(Quantity) FROM gives_raw_milk_to WHERE Supplier_ID=' + str(item[0]))):
            quantity = i[0]
        if(quantity==None):
            quantity = 0
        farmers.append([item[0],item[2], item[3], quantity])
    return render_template('admin_farmers.html', aid=aid, farmers=farmers)

@app.route("/transactions_farmer_admin/<int:aid>", methods=['GET', 'POST'])
def trasactions_farmer_admin(aid):
    transactions = []
    for item in db.session.execute(text('SELECT * FROM gives_raw_milk_to')):
        transactions.append(item)
    return render_template('admin_farmer_transactions.html', aid=aid, t=transactions)
app.run(debug=True)