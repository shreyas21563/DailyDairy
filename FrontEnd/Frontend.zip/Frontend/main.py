from flask import Flask, render_template, request, redirect, url_for
from sqlalchemy import text
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import random
app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:mp09lh3818@localhost/dailydairy'
db = SQLAlchemy(app)

class Cart(db.Model):
    Cart_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Cart_Value = db.Column(db.Integer, nullable=False)
    customers=db.relationship('Customer', backref='cartbr')

class Adds(db.Model):
    Customer_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Product_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Cart_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Quantity = db.Column(db.Integer, nullable=False)

class Customer(db.Model):
    Customer_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    First_Name = db.Column(db.String(50), nullable=False)
    Last_Name = db.Column(db.String(50), nullable=False)
    Apartment_Number = db.Column(db.Integer, nullable=False)
    Locality = db.Column(db.String(100), nullable=False)
    City = db.Column(db.String(50), nullable=False)
    State = db.Column(db.String(50), nullable=False)
    Pincode = db.Column(db.Integer, nullable=False)
    Password = db.Column(db.String(50), nullable=False)
    Email_ID = db.Column(db.String(50), nullable=False, unique=True)
    Cart_ID = db.Column(db.Integer, db.ForeignKey('cart.Cart_ID'))

class gives_product_feedback(db.Model):
    Customer_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Product_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Order_ID = db.Column(db.Integer, primary_key=True, nullable=False)
    Rating = db.Column(db.Integer, nullable=False)

@app.route("/")
def home():
    return render_template('index.html')

@app.route("/signup", methods=['GET', 'POST'])
def signup():
    if(request.method=='POST'):
        cart = Cart(Cart_Value=0)
        firstname = request.form.get('firstname')
        lastname = request.form.get('lastname')
        ap_num = request.form.get('ap_num')
        locality = request.form.get('locality')
        city = request.form.get('city')
        state = request.form.get('state')
        pincode = request.form.get('pincode')
        password = request.form.get('password')
        email = request.form.get('email')
        entry = Customer(First_Name=firstname, Last_Name=lastname, Apartment_Number=ap_num, Locality=locality, City=city, State=state, Pincode=pincode, Password=password, Email_ID=email, cartbr=cart)
        db.session.add(cart)
        db.session.add(entry)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route("/login", methods = ['GET', 'POST'])
def login():
    if(request.method=='POST'):
        email = request.form.get('email')
        password = request.form.get('password')
        result = db.session.execute(text('SELECT Customer.Customer_ID, Customer.Email_ID, Customer.Password FROM Customer'))
        for output in result:
            if(email==output[1] and password==output[2]):
                return redirect(url_for('account', id=output[0]))
        
    return render_template('login.html')

@app.route("/account/<int:id>", methods=["GET"])
def account(id):  
    acc = Customer.query.filter_by(Customer_ID=id).first()
    return render_template('account.html', cus=acc)

@app.route("/Payment/<int:cid>/<int:oid>/<int:amount>")
def Payment(cid, oid, amount):
    transaction_number = random.randint(1000000, 9999999)
    db.session.execute(text("START TRANSACTION;INSERT INTO `payment`(`Customer_ID`, `Order_ID`, `Amount`, `Transaction_Number`) VALUES ("+str(cid)+", "+str(oid)+", "+str(amount)+", "+str(transaction_number)+");UPDATE `customer` SET `Money In Wallet` = `Money In Wallet` - "+str(amount)+" WHERE `Customer_ID` = "+str(cid)+";UPDATE `admin` SET `Money` = `Money` + "+str(amount)+";"))
    db.session.commit()
    return redirect(url_for('Products', id=cid))

@app.route("/Products/<int:id>", methods=["GET", "POST"])
def Products(id):
    Pro = db.session.execute(text('SELECT * FROM Product'))
    if(request.method=='POST'):
        description = request.form.get('description')
        Pro = db.session.execute(text("SELECT * FROM Product WHERE Product.`Description` LIKE '%" + description +"%';"))
    Pro_Cart = db.session.execute(text('SELECT * FROM Adds where Adds.Customer_ID='+str(id)))
    Value = db.session.execute(text('SELECT Cart.Cart_Value From Cart where Cart.Cart_ID='+str(id)))
    for item in db.session.execute(text('SELECT `Money In Wallet` from customer where customer_id=' + str(id))):
        money = item[0]
    value=0
    for val in Value:
        value=val
    acc = Customer.query.filter_by(Customer_ID=id).first()
    L = []
    for items in Pro_Cart:
        L.append(items)
    return render_template('product.html', cus=acc, pro=Pro, id=id, Pro_Cart=L, value=value[0], money = money)

@app.route("/add_product/<int:pid>/<int:cid>", methods=["GET"])
def add_product(pid, cid):  
    if(request.method=='GET'):
        Pro_Cart = db.session.execute(text('SELECT * FROM Adds where Adds.Customer_ID='+str(cid)+' and Adds.Product_ID='+str(pid)))
        L = []
        for items in Pro_Cart:
            L.append(items)
        if(L==[]):
            add = Adds(Customer_ID = cid, Product_ID=pid, Quantity=1, Cart_ID = cid)
            db.session.add(add)
            db.session.commit()
        else:
            for i in Adds.query.filter_by(Customer_ID=cid, Product_ID=pid):
                i.Quantity = i.Quantity+1
            db.session.flush()
            db.session.commit()
        return redirect(url_for('Products', id=cid))
@app.route("/delete_product/<int:pid>/<int:cid>", methods=["GET"])
def delete_product(pid, cid):  
    if(request.method=='GET'):
        Pro_Cart = db.session.execute(text('SELECT * FROM Adds where Adds.Customer_ID='+str(cid)+' and Adds.Product_ID='+str(pid)))
        L = []
        for items in Pro_Cart:
            L.append(items)
        if(L!=[]):
            for i in Adds.query.filter_by(Customer_ID=cid, Product_ID=pid):
                if(i.Quantity>0):
                    i.Quantity = i.Quantity-1
                if(i.Quantity==0):
                    db.session.delete(i)
            db.session.flush()
            db.session.commit()
        return redirect(url_for('Products', id=cid))
@app.route("/remove_product/<int:pid>/<int:cid>", methods=["GET"])
def remove_product(pid, cid):  
    if(request.method=='GET'):
        Pro_Cart = db.session.execute(text('SELECT * FROM Adds where Adds.Customer_ID='+str(cid)+' and Adds.Product_ID='+str(pid)))
        L = []
        for items in Pro_Cart:
            L.append(items)
        if(L!=[]):
            for i in Adds.query.filter_by(Customer_ID=cid, Product_ID=pid):
                db.session.delete(i)
            db.session.commit()
        return redirect(url_for('Products', id=cid))

@app.route("/Orders/<int:id>", methods=["GET"])
def Orders(id):
    acc = Customer.query.filter_by(Customer_ID=id).first()
    orders = db.session.execute(text('SELECT * FROM `order` where `order`.Customer_ID='+str(id)))
    return render_template('orders.html', O=orders, id=id, cus=acc)

@app.route("/OrderDetails/<int:cid>/<int:oid>", methods=["GET"])
def OrderDetails(cid, oid):
    acc = Customer.query.filter_by(Customer_ID=cid).first() 
    given_feedback = db.session.execute(text('select gives_product_feedback.Product_ID from gives_product_feedback where gives_product_feedback.Order_ID='+str(oid)+' and gives_product_feedback.Customer_ID='+str(cid)))
    L = []
    for items in given_feedback:
        L.append(items[0])
    pro = db.session.execute(text('select * from order_placing inner join Product on Product.Product_ID=order_placing.Product_ID where order_placing.Order_ID='+str(oid)))
    return render_template('order_details.html', id=cid, oid=oid, cus=acc, pro=pro, given_feedback=L)

@app.route("/Rating/<int:cid>/<int:oid>/<int:pid>", methods=["POST"])
def Rating(cid, oid, pid): 
    if(request.method=='POST'):
        rating = int(request.form.get('rating'))
        db.session.execute(text('START TRANSACTION;SET @Customer_ID = '+str(cid)+';SET @Order_ID='+str(oid)+';SET @Product_ID = '+str(pid)+';SET @Rating = '+str(rating)+';INSERT INTO `gives_product_feedback` VALUES (@Customer_ID, @Order_ID, @Product_ID, @Rating);UPDATE `Product` SET Average_Rating = (SELECT AVG(gives_product_feedback.Rating) FROM gives_product_feedback WHERE gives_product_feedback.Product_ID = @Product_ID) WHERE `Product_ID` = @Product_ID;COMMIT;'))
        db.session.commit()
    return redirect(url_for('OrderDetails', cid=cid, oid=oid))

@app.route("/Place_order/<int:cid>", methods=["GET"])
def Place_Order(cid): 
    if(request.method=='GET'):
        o = db.session.execute(text('SELECT MAX(order_id) FROM `order`'))
        i = db.session.execute(text('SELECT MAX(Delivery_Man_ID) from delivery_man'))
        for item in i:
            # print(max_delivery_man)
            max_delivery_man=item[0]
        delivery_man_id = random.randint(1, max_delivery_man)
        warehouse_id = random.randint(1, 100)
        order_id=1
        v = db.session.execute(text('SELECT cart_value FROM Cart WHERE cart.cart_id=' + str(cid) + ';'))
        for item in o:
            if(item[0]!=None):
                order_id = item[0]+1
        for item in v:
            order_value = item[0]
        for item in db.session.execute(text('SELECT `Money in Wallet` from customer where customer_id = '+str(cid))):
            money = item[0]
        if(money>=order_value):
            db.session.execute(text("INSERT INTO `order` VALUES ("+str(order_id)+"," +"'Order Confirmed'"+", "+str(delivery_man_id)+", "+str(warehouse_id)+", "+str(cid)+", "+str(order_value)+");"))
            db.session.execute(text('INSERT INTO `order_placing`(`product_id`, `order_id`, `cart_id`, `quantity`) SELECT `product_id`,'+ str(order_id)+', '+str(cid)+', quantity FROM Adds WHERE `Customer_ID` = '+str(cid)+';'))
            db.session.execute(text('DELETE FROM adds WHERE customer_id='+str(cid)+';'))
            db.session.commit()
            return redirect(url_for('Payment', cid=cid, oid=order_id, amount=order_value))
        return redirect(url_for('Products', id=cid))
@app.route("/wallet/<int:cid>", methods=['GET', 'POST'])
def wallet(cid):
    if(request.method=='POST'):
        money = int(request.form.get('money'))
        word = request.form.get('password')
        for item in db.session.execute(text('SELECT Password from customer where customer_id='+str(cid))):
            password = item[0]
        if(password==word):
            db.session.execute(text('UPDATE customer SET `Money In Wallet`=`Money In Wallet`+' + str(money) + ' WHERE customer_id='+str(cid)))
            db.session.commit()
    for item in db.session.execute(text('SELECT `money in wallet` from customer where customer_ID=' + str(cid))):
        m = item[0]
    return render_template('wallet.html', id=cid, m=m)

@app.route("/index_admin", methods=['GET', 'POST'])
def index_admin():
    return render_template('admin_index.html')

@app.route("/login_admin", methods=['GET', 'POST'])
def login_admin():
    if(request.method=='POST'):
        admin_id = request.form.get('admin_id')
        password = request.form.get('password')
        result = db.session.execute(text('SELECT Admin_ID, Password FROM Admin'))
        for output in result:
            if(int(admin_id)==int(output[0]) and password==output[1]):
                return redirect(url_for('account_admin', aid=output[0]))
    return render_template('admin_login.html')

@app.route("/account_admin/<int:aid>", methods=['GET', 'POST'])
def account_admin(aid):
    return render_template('admin_account.html', aid=aid)

@app.route("/products_admin/<int:aid>", methods = ['GET', 'POST'])
def products_admin(aid):
    products = db.session.execute(text('SELECT * FROM Product'))
    return render_template('admin_products.html', pro=products, aid=aid)

@app.route("/update_price/<int:aid>/<int:pid>", methods=['GET', 'POST'])
def update_price(aid, pid):
    if(request.method=='POST'):
        new_price = int(request.form.get('new_price'))
        db.session.execute(text('START TRANSACTION;SET @product_id = '+str(pid)+';SET @old_value = (SELECT Product_Value FROM product WHERE product_id=@product_id);SET @new_value = '+str(new_price)+';UPDATE cart, adds SET cart.cart_value = cart_value + adds.Quantity*(@new_value - @old_value) WHERE cart.Cart_ID = adds.Cart_ID AND adds.Product_ID=@product_id;UPDATE product SET product_value = @new_value WHERE product_id=@product_id;COMMIT;'))
    return redirect(url_for('products_admin', aid=aid))

@app.route("/wallet_admin/<int:aid>", methods=['GET', 'POST'])
def wallet_admin(aid):
    if(request.method=='POST'):
        money = int(request.form.get('money'))
        word = request.form.get('password')
        for item in db.session.execute(text('SELECT Password from Admin where admin_id='+str(aid))):
            password = item[0]
        if(password==word):
            db.session.execute(text('UPDATE Admin SET `Money`=`Money`+' + str(money) + ' WHERE admin_id='+str(aid)))
            db.session.commit()
    for item in db.session.execute(text('SELECT `Money` from Admin where Admin_ID=' + str(aid))):
        m = item[0]
    return render_template('admin_wallet.html', aid=aid, m=m)

@app.route("/farmers_admin/<int:aid>", methods=['GET', 'POST'])
def farmers_admin(aid):
    farmers = []
    for item in db.session.execute(text('SELECT * from farmer')):
        for i in db.session.execute(text('SELECT SUM(Quantity) FROM gives_raw_milk_to WHERE Supplier_ID=' + str(item[0]))):
            quantity = i[0]
        if(quantity==None):
            quantity = 0
        farmers.append([item[0],item[3], item[4], quantity])
    return render_template('admin_farmers.html', aid=aid, farmers=farmers)

@app.route("/transactions_farmer_admin/<int:aid>", methods=['GET', 'POST'])
def trasactions_farmer_admin(aid):
    transactions = []
    for item in db.session.execute(text('SELECT * FROM gives_raw_milk_to')):
        transactions.append(item)
    return render_template('admin_farmer_transactions.html', aid=aid, t=transactions)

@app.route("/worker_admin/<int:aid>", methods=['GET', 'POST'])
def worker_admin(aid):
    unit_workers = db.session.execute(text('SELECT * FROM unit_worker'))
    warehouse_worker = db.session.execute(text('SELECT * FROM warehouse_worker'))
    return render_template('admin_worker.html', aid=aid, unit_workers=unit_workers, warehouse_worker=warehouse_worker)

@app.route("/increment_worker_admin/<int:aid>", methods=['GET', 'POST'])
def increment_worker_admin(aid):
    increment = float(1 + (int(request.form.get('percentage'))/100))
    print(increment)
    db.session.execute(text('START TRANSACTION;SET @Increment = '+str(increment)+';UPDATE `unit_worker` SET `Salary` = @Increment*`Salary`;UPDATE `warehouse_worker` SET `Salary` = @Increment*`Salary`;CREATE OR REPLACE VIEW `unit workers` AS SELECT Processing_Unit.Unit_ID, SUM(unit_worker.salary) AS Unit_Worker_Salary FROM Processing_Unit INNER JOIN Unit_Worker ON Unit_Worker.Unit_ID=Processing_Unit.Unit_ID GROUP BY Unit_ID ORDER BY Unit_ID;CREATE OR REPLACE VIEW `warehouse worker` AS SELECT Warehouse.Warehouse_ID, Warehouse.Unit_ID, SUM(warehouse_worker.salary) AS Warehouse_Worker_Salaries FROM Warehouse INNER JOIN warehouse_worker ON Warehouse_worker.Warehouse_ID = Warehouse.Warehouse_ID GROUP BY Warehouse_ID ORDER BY Warehouse_ID;COMMIT;'))
    db.session.commit()
    return redirect(url_for('worker_admin', aid=aid))

@app.route("/processing_unit_admin/<int:aid>", methods=['GET', 'POST'])
def processing_unit_admin(aid):
    processing_unit = []
    for item in db.session.execute(text('SELECT * FROM `unit workers`')):
        for i in db.session.execute(text('SELECT locality, Warehouse_ID from processing_unit where unit_id='+str(item[0]))):
            locality = i[0]
            warehouse_id = i[1]
        processing_unit.append([item[0], item[1], locality, warehouse_id])
    return render_template('admin_processing_unit.html', processing_unit=processing_unit, aid=aid)

@app.route("/warehouse_admin/<int:aid>", methods=['GET', 'POST'])
def warehouse_admin(aid):
    warehouse = []
    for item in db.session.execute(text('SELECT * FROM `warehouse worker`')):
        for i in db.session.execute(text('SELECT Unit_ID, Locality, Pincode from warehouse where warehouse_id='+str(item[0]))):
            locality = i[1]
            unit_id = i[0]
            pincode = i[2]
        for i in db.session.execute(text('SELECT COUNT(order_id) from `order` where `order`.warehouse_id=' + str(item[0]))):
            num_orders = i[0]
        warehouse.append([item[0], item[2], locality, unit_id, pincode, num_orders])
    return render_template('admin_warehouse.html', warehouse=warehouse, aid=aid)
@app.route("/customer_admin/<int:aid>", methods=['GET', 'POST'])
def customer_admin(aid):
    customer = []
    for item in db.session.execute(text('SELECT Customer_ID from Customer')):
        print(item[0])
        for i in db.session.execute(text('SELECT Count(Customer_ID), SUM(order_value) from `order` where customer_ID='+str(item[0]))):
            num_orders = i[0]
            order_value = i[1]
        customer.append([item[0], num_orders, order_value])
    return render_template('admin_customer.html', cus=customer, aid=aid)

@app.route("/delivery_man_admin/<int:aid>", methods=['GET', 'POST'])
def delivery_man_admin(aid):
    delivery_man = []
    for item in db.session.execute(text('SELECT delivery_man_id, first_name, last_name, Number_of_order_Delivered from delivery_man')):
        delivery_man.append([item[0], item[1], item[2], item[3]])
    return render_template('admin_delivery_man.html',man=delivery_man, aid=aid)

@app.route("/index_farmer", methods=['GET', 'POST'])
def index_farmer():
    return render_template('farmer_index.html')

@app.route("/signup_farmer", methods=['GET', 'POST'])
def signup_farmer():
    if(request.method=='POST'):
        farmer_email = request.form.get('farmer_email')
        word = request.form.get('farmer_password')
        db.session.execute(text(f"INSERT INTO farmer (Email_ID, Password) VALUES ('{farmer_email}', '{word}')"))
        db.session.commit()
        return redirect(url_for('login_farmer'))
    return render_template('farmer_signup.html')

@app.route("/login_farmer", methods=['GET', 'POST'])
def login_farmer():
    if(request.method=='POST'):
        farmer_email = request.form.get('farmer_email_login')
        word = request.form.get('farmer_password_login')
        for item in db.session.execute(text(f"SELECT * FROM farmer WHERE Email_ID='{farmer_email}'")):
            if(item[2]==word):
                return redirect(url_for('account_farmer', sid=item[0]))    
    return render_template('farmer_login.html')

@app.route("/account_farmer/<int:sid>", methods=['GET', 'POST'])
def account_farmer(sid):
    return render_template('farmer_account.html', sid=sid)

@app.route("/sell_farmer/<int:sid>", methods=['GET', 'POST'])
def sell_farmer(sid):
    if(request.method=='POST'):
        word = request.form.get('farmer_sell_password')
        for item in db.session.execute(text('SELECT Password from farmer where Supplier_ID='+str(sid))):
            Password = item[0]
        if(word==Password):
            unit_id = request.form.get('farmer_sell_unit_id')
            quantity = request.form.get('farmer_sell_quantity')
            price = request.form.get('farmer_sell_price')
            db.session.execute(text(f"START TRANSACTION;SET @Quantity = {quantity};SET @Price = {price};SET @Unit_ID = {unit_id};SET @Supplier_ID = {sid};INSERT INTO `gives_raw_milk_to`(Unit_ID, Supplier_ID, Quantity, Price) VALUES (@Unit_ID, @Supplier_ID, @Quantity, @Price);UPDATE `admin` SET `Money` = `Money` - @Price * @Quantity;UPDATE `farmer` SET `Money In Wallet` = `Money In Wallet` + @Price * @Quantity WHERE `farmer`.`Supplier_ID` = @Supplier_ID;UPDATE `farmer` SET `Average Price` = (SELECT SUM(Quantity*Price) FROM `gives_raw_milk_to` WHERE `gives_raw_milk_to`.`Supplier_ID`=@Supplier_ID)/(SELECT SUM(Quantity) FROM `gives_raw_milk_to` WHERE `gives_raw_milk_to`.`Supplier_ID`=@Supplier_ID) WHERE `farmer`.`Supplier_ID`=@Supplier_ID;COMMIT;"))
            db.session.commit()
    for item in db.session.execute(text('SELECT `Average Price` from farmer where Supplier_ID='+str(sid))):
        avg_price = item[0]
    return render_template('farmer_sell.html', sid=sid, avg_price = avg_price)

@app.route("/wallet_farmer/<int:sid>", methods=['GET', 'POST'])
def wallet_farmer(sid):
    for item in db.session.execute(text('SELECT `money in wallet` from farmer where supplier_id='+str(sid))):
        money=item[0]
    return render_template('farmer_wallet.html', sid=sid, money=money)

@app.route("/transactions_farmer/<int:sid>", methods=['GET', 'POST'])
def transactions_farmer(sid):
    trans = []
    for item in db.session.execute(text('SELECT * FROM gives_raw_milk_to WHERE Supplier_ID='+str(sid))):
        trans.append([item[0], item[2], item[3], item[4]])
    return render_template('farmer_transactions.html', trans=trans, sid=sid) 

@app.route("/index_delivery_man", methods=['GET', 'POST'])
def index_delivery_man():
    return render_template('delivery_man_index.html')

@app.route("/signup_delivery_man", methods=['GET', 'POST'])
def signup_delivery_man():
    if(request.method=='POST'):
        firstname = request.form.get('dm_firstname')
        lastname = request.form.get('dm_lastname')
        city = request.form.get('dm_city')
        state = request.form.get('dm_state')
        email = request.form.get('dm_email')
        password = request.form.get('dm_password')
        db.session.execute(text(f"INSERT INTO delivery_man (First_Name, Last_Name, City, State, Email_ID, Password) VALUES ('{firstname}', '{lastname}', '{city}', '{state}', '{email}', '{password}')"))
        db.session.commit()
        return redirect(url_for('login_delivery_man'))
    return render_template('delivery_man_signup.html')

@app.route("/login_delivery_man", methods=['GET', 'POST'])
def login_delivery_man():
    if(request.method=='POST'):
        email = request.form.get('dm_login_delivery_man_email')
        word = request.form.get('dm_login_delivery_man_password')
        for item in db.session.execute(text(f"SELECT password, delivery_man_id from delivery_man where email_id='{str(email)}'")):
            if(item[0]==word):
                return redirect(url_for('account_delivery_man', did=item[1]))
    return render_template('delivery_man_login.html')

@app.route("/account_delivery_man/<int:did>", methods=['GET', 'POST'])
def account_delivery_man(did):
    return render_template('delivery_man_account.html', did=did)

@app.route("/orders_delivery_man/<int:did>", methods=['GET', 'POST'])
def orders_delivery_man(did):
    orders = []
    for item in db.session.execute(text(f"SELECT order_id, customer_id from `order` where order_status='Order Confirmed' and Delivery_Man_ID={str(did)}")):
        for address in db.session.execute(text(f"SELECT apartment_number, locality, city, state, pincode, first_name, last_name from customer where customer_id={str(item[1])}")):
            ap_number = address[0]
            locality = address[1]
            city = address[2]
            state = address[3]
            pincode = address[4]
            first_name = address[5]
            last_name = address[6]
        orders.append([item[0], first_name, last_name, ap_number, locality, city, state, pincode])
    for i in db.session.execute(text(f"SELECT Number_of_order_delivered from delivery_man where delivery_man_id={str(did)}")):
        total_order=i[0]
    return render_template('delivery_man_orders.html', did=did, orders=orders, total_orders=total_order)

@app.route("/delivery_man_change_status/<int:oid>/<int:did>", methods=['GET', 'POST'])
def delivery_man_change_status(oid, did):
    if(request.method=='POST'):
        db.session.execute(text(f"START TRANSACTION;SET @delivery_man_id = {str(did)};SET @order_id = {str(oid)};UPDATE `order` SET `order_status` = 'Order Delivered' WHERE `order_id` = @order_id;UPDATE `delivery_man` SET `Number_Of_Order_Delivered` = `Number_Of_Order_Delivered` + 1 WHERE Delivery_Man_ID = @delivery_man_id;COMMIT;"))
    return redirect(url_for('orders_delivery_man', did=did))   
app.run(debug=True)